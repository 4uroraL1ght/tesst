# web-programming-fullstack demo video link: https://rmiteduau-my.sharepoint.com/:v:/g/personal/s3750945_student_rmit_edu_au/EZOctBoQtFxIswRp9jjbiu4B87_6WaVp2rmU6mRlRXyJpg?e=s0gqvE

# Github url: https://github.com/jamesdinhh/group_asm.git

# Step to start the application
- On the terminal or cmd of the root folder, type this php -S localhost:{portnumber}
- Access the localhost:{portnumber}/index.php to register a user account and follow the step through login and test user site.

CONTRIBUTION:

Kha Nguyen Anh Tran s3750945: 40% 


Dinh Le Hong Tin s3932134: 35%

Nguyen Nhu Xuan Nguyen s3922415: 15%

Vo Minh Thien An s3916570: 10%

# User Account
* CUSTOMER ||
username: customer <=>
password: Lazada2022!

* VENDOR ||
username: lazadavendor <=>
password: Rmit2022!

* SHIPPER ||
username: rmitshipper <=>
password: Shipper2022!

* YOUR ACCOUNT ||
email: (you create!) <=>
password: (you create!)

# Feel free to acceess our Github page at anytime
Access directly via: https://github.com/jamesdinhh/group_asm.git

# DB description
# User Account
accounts.db: outside document root
[0]: hased registration id
[1]: username
[2]: password

# Handling session profile image
profilePicture.db: inside profileImgRepo folder
[0]: email
[1]: profile img name
