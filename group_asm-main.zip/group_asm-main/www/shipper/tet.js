var noti = document.getElementById("default-item1");
noti.addEventListener("keypress", function(event) {
  if (event.key === "Enter") {
    event.preventDefault();
    document.getElementById("myBtn").click();
  }
});
var noti = document.getElementById("default-item2");
noti.addEventListener("keypress", function(event) {
  if (event.key === "Enter") {
    event.preventDefault();
    document.getElementById("myBtn").click();
  }
});
var noti = document.getElementById("default-item3");
noti.addEventListener("keypress", function(event) {
  if (event.key === "Enter") {
    event.preventDefault();
    document.getElementById("myBtn").click();
  }
});
var noti = document.getElementById("default-item4");
noti.addEventListener("keypress", function(event) {
  if (event.key === "Enter") {
    event.preventDefault();
    document.getElementById("myBtn").click();
  }
});
var noti = document.getElementById("default-item5");
noti.addEventListener("keypress", function(event) {
  if (event.key === "Enter") {
    event.preventDefault();
    document.getElementById("myBtn").click();
  }
});
var noti = document.getElementById("default-item6");
noti.addEventListener("keypress", function(event) {
  if (event.key === "Enter") {
    event.preventDefault();
    document.getElementById("myBtn").click();
  }
});
var noti = document.getElementById("default-item7");
noti.addEventListener("keypress", function(event) {
  if (event.key === "Enter") {
    event.preventDefault();
    document.getElementById("myBtn").click();
  }
});
var noti = document.getElementById("default-item8");
noti.addEventListener("keypress", function(event) {
  if (event.key === "Enter") {
    event.preventDefault();
    document.getElementById("myBtn").click();
  }
});
var a;
function invi1(){
    if(a == 1)
        {
            document.getElementById("ship_card1").style.display = "inline";
            return a =0;
        }
    else 
        {
            document.getElementById("ship_card1").style.display = "none";
            return a =1;
        }
};

var b;
function invi2(){
    if(b == 1)
        {
            document.getElementById("ship_card2").style.display = "none";
            return b =0;
        }
    else 
        {
            document.getElementById("ship_card2").style.display = "none";
            return b =1;
        }
};
var c;
function invi3(){
    if(c == 1)
        {
            document.getElementById("ship_card3").style.display = "inline";
            return c =0;
        }
    else 
        {
            document.getElementById("ship_card3").style.display = "none";
            return c =1;
        }
};
var d;
function invi4(){
    if(d == 1)
        {
            document.getElementById("ship_card4").style.display = "inline";
            return d =0;
        }
    else 
        {
            document.getElementById("ship_card4").style.display = "none";
            return d =1;
        }
};
var e;
function invi5(){
    if(e == 1)
        {
            document.getElementById("ship_card5").style.display = "inline";
            return e =0;
        }
    else 
        {
            document.getElementById("ship_card5").style.display = "none";
            return e =1;
        }
};
var f;
function invi6(){
    if(f == 1)
        {
            document.getElementById("ship_card6").style.display = "inline";
            return f =0;
        }
    else 
        {
            document.getElementById("ship_card6").style.display = "none";
            return f =1;
        }
};
var g;
function invi7(){
    if(g == 1)
        {
            document.getElementById("ship_card7").style.display = "inline";
            return g =0;
        }
    else 
        {
            document.getElementById("ship_card7").style.display = "none";
            return g =1;
        }
};
var h;
function invi8(){
    if(b == 1)
        {
            document.getElementById("ship_card8").style.display = "inline";
            return h =0;
        }
    else 
        {
            document.getElementById("ship_card8").style.display = "none";
            return h =1;
        }
};
/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
function myDrop1() {
  document.getElementById("dropbox1").classList.toggle("show");
}

function myDrop2() {
  document.getElementById("dropbox2").classList.toggle("show");
}

function myDrop3() {
  document.getElementById("dropbox3").classList.toggle("show");
}

function myDrop4() {
  document.getElementById("dropbox4").classList.toggle("show");
}

function myDrop5() {
  document.getElementById("dropbox5").classList.toggle("show");
}

function myDrop6() {
  document.getElementById("dropbox6").classList.toggle("show");
}

function myDrop7() {
  document.getElementById("dropbox7").classList.toggle("show");
}

function myDrop8() {
  document.getElementById("dropbox8").classList.toggle("show");
}
