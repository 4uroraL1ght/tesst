<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Copyright</title>
    <link rel="stylesheet" href="../headerFooter/headerFooter.css">
</head>
<body>
    <?php include '../headerFooter/header.php'?>
    <div class="main" style="margin:170px 280px 0px 280px; text-align: center;">
        <a href="../customer/customer.php">&lt; &lt; GO BACK </a>
        <h2>Copyright</h2>
        <br>
        <h4>&copy; 2022 Group6.git</h4>
        <br>
        <p>
           Lorem ipsum dolor sit amet consectetur adipisicing elit. 
           Modi eos atque optio voluptatem eius. Ab exercitationem quidem quaerat sit reprehenderit fugit, 
           doloremque ratione est reiciendis repellendus! Commodi maiores exercitationem aperiam. 
           Lorem ipsum dolor sit amet consectetur adipisicing elit. 
           Modi eos atque optio voluptatem eius. Ab exercitationem quidem quaerat sit reprehenderit fugit, 
           doloremque ratione est reiciendis repellendus! Commodi maiores exercitationem aperiam. 
           Lorem ipsum dolor sit amet consectetur adipisicing elit. 
           Modi eos atque optio voluptatem eius. Ab exercitationem quidem quaerat sit reprehenderit fugit, 
           doloremque ratione est reiciendis repellendus! Commodi maiores exercitationem aperiam. 
           Lorem ipsum dolor sit amet consectetur adipisicing elit. 
           Modi eos atque optio voluptatem eius. Ab exercitationem quidem quaerat sit reprehenderit fugit, 
           doloremque ratione est reiciendis repellendus! Commodi maiores exercitationem aperiam. 
        </p>
    </div>
    <?php include '../headerFooter/footer.php'?>
</body>
</html>