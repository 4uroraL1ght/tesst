<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="stylesheet" href="../headerFooter/headerFooter.css">
</head>
<body>
    <?php include '../headerFooter/header.php'?>

    <div class="main" style="margin:170px 280px 0px 280px; text-align: center;">
        <a href="../customer/customer.php">&lt; &lt; GO BACK </a>
        <h2>About Us</h2>
        <h4>Team Member</h4>
        <ul style="list-style: none">
            <li>Kha Tran</li>
            <li>Hong Tin</li>
            <li>Xuan Nguyen</li>
            <li>Minh An</li>
        </ul>
        <br>
        <h4>More about us</h4>
        <p>
           Lorem ipsum dolor sit amet consectetur adipisicing elit. 
           Modi eos atque optio voluptatem eius. Ab exercitationem quidem quaerat sit reprehenderit fugit, 
           doloremque ratione est reiciendis repellendus! Commodi maiores exercitationem aperiam. 
           Lorem ipsum dolor sit amet consectetur adipisicing elit. 
           Modi eos atque optio voluptatem eius. Ab exercitationem quidem quaerat sit reprehenderit fugit, 
           doloremque ratione est reiciendis repellendus! Commodi maiores exercitationem aperiam. 
           Lorem ipsum dolor sit amet consectetur adipisicing elit. 
           Modi eos atque optio voluptatem eius. Ab exercitationem quidem quaerat sit reprehenderit fugit, 
           doloremque ratione est reiciendis repellendus! Commodi maiores exercitationem aperiam. 
           Lorem ipsum dolor sit amet consectetur adipisicing elit. 
           Modi eos atque optio voluptatem eius. Ab exercitationem quidem quaerat sit reprehenderit fugit, 
           doloremque ratione est reiciendis repellendus! Commodi maiores exercitationem aperiam. 
        </p>
    </div>
    <?php include '../headerFooter/footer.php'?>
</body>
</html>